export { default as ThankYouModal } from './ThankYouModal.vue'
