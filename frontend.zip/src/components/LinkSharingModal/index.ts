export { default } from './LinkSharingModal.vue'
