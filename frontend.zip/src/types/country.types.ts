export interface CountryCode {
  name: string
  nameAr: string
  code: string
  dialCode: string
  flag: string
}
