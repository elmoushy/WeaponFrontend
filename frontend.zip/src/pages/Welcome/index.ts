// Export Welcome page for easy importing
export { default as Welcome } from './Welcome.vue'
